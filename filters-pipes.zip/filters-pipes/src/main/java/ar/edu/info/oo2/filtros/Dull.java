package ar.edu.info.oo2.filtros;

import java.util.Iterator;
import java.io.File;
import java.io.IOException;
import javax.imageio.*;
import javax.imageio.stream.*;
import java.awt.image.BufferedImage;

public class Dull extends AbstractFilter {
  
  
    
  public BufferedImage filter(BufferedImage image) {
    
    return image;
  }
}
