package ar.edu.info.oo2.filtros;

import java.awt.image.BufferedImage;


public interface ImageFilter {
    
    public BufferedImage filter(BufferedImage image);
    
}
